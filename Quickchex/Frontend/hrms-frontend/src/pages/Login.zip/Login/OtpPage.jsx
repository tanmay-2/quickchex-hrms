import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./LoginPage.css";
import loginImg from "../../assets/img/loginImg.jpg";

const OtpPage = () => {
  const navigate = useNavigate();
  const location = useLocation(); // 🔥 IMPORTANT
  const [otp, setOtp] = useState("");

  const handleVerify = async () => {
    if (!otp) {
      alert("Please enter OTP");
      return;
    }

    try {
      const res = await fetch("http://localhost:8000/api/v1/auth/verify-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email: location.state?.email, // 🔥 safe access
          otp: otp
        })
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.detail || "OTP failed");
        return;
      }

      // ✅ STORE TOKEN (IMPORTANT)
      localStorage.setItem("token", data.access_token);
      localStorage.setItem("role", data.role);

      // 🔥 ROUTE DECISION
      const role = data.role;

      if (data.must_change_password) {
        navigate("/reset-password");
      } else {
        if (role === "admin") {
          navigate("/dashboard");
        } else {
          navigate("/dashboard/attendance");
        }
      }

    } catch (err) {
      alert("Server error");
    }
  };

  return (
    <div className="container">
      <div
        className="left"
        style={{ backgroundImage: `url(${loginImg})` }}
      ></div>

      <div className="right">
        <div className="form">
          <div className="form-header">
            <h2 className="logo">LAEsfera</h2>
            <h3 className="heading">OTP Verification</h3>
            <p className="subtitle">
              We need to verify that it is really you before you login
            </p>
          </div>

          <div className="input">
            <input
              type="text"
              placeholder="Enter OTP"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
            />
          </div>

          <button className="login-btn" onClick={handleVerify}>
            🔐 Log Me In
          </button>
        </div>
      </div>
    </div>
  );
};

export default OtpPage;