import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./LoginPage.css"; // reuse same styling
import loginImg from "../../assets/img/loginImg.jpg";

const ResetPassword = () => {
  const navigate = useNavigate();

  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");

  const handleReset = async () => {
    setError("");

    // ✅ Validation
    if (!password || !confirm) {
      setError("All fields are required");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }

    if (password !== confirm) {
      setError("Passwords do not match");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("http://localhost:8000/api/v1/auth/reset-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("token")}` // 🔥 IMPORTANT
        },
        body: JSON.stringify({
          new_password: password
        })
      });

      const data = await res.json();

      if (res.ok) {
        setSuccess("Password updated successfully 🎉");

        setTimeout(() => {
          navigate("/dashboard");
        }, 1500);
      }

      alert("Password updated successfully 🎉");

      // ✅ redirect to dashboard
      navigate("/dashboard");

    } catch (err) {
      setError("Server error. Try again.");
    }

    setLoading(false);
  };

  return (
    <div className="container">

      {/* LEFT SIDE IMAGE */}
      <div
        className="left"
        style={{ backgroundImage: `url(${loginImg})` }}
      ></div>

      {/* RIGHT SIDE FORM */}
      <div className="right">
        <div className="form">

          {/* HEADER */}
          <div className="form-header">
            <h2 className="logo">LaEsfera</h2>
            <h3 className="heading">Reset Password</h3>
            <p className="subtitle">
              Set your new secure password
            </p>
          </div>

          {/* NEW PASSWORD */}
          <div className="field">
            <div className="input">
              <input
                type="password"
                placeholder="Enter New Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          {/* CONFIRM PASSWORD */}
          <div className="field">
            <div className="input">
              <input
                type="password"
                placeholder="Confirm Password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
              />
            </div>
          </div>

          {/* ERROR */}
          {error && (
            <div className="custom-alert error">
              <span>{error}</span>
              <button onClick={() => setError("")}>✕</button>
            </div>
          )}
          {success && (
            <div className="custom-alert success">
              <span>{success}</span>
            </div>
          )}

          {/* BUTTON */}
          <button
            className="login-btn"
            onClick={handleReset}
            disabled={loading}
          >
            {loading ? "Updating..." : "Update Password"}
          </button>

        </div>
      </div>

    </div>
  );
};

export default ResetPassword;