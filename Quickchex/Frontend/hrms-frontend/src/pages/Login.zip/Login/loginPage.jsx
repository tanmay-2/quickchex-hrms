import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./LoginPage.css";
import loginImg from "../../assets/img/loginImg.jpg";

const LoginPage = () => {
  const navigate = useNavigate();

  // ✅ STATE
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [errors, setErrors] = useState({
    email: "",
    password: "",
    general: ""
  });

  const [loading, setLoading] = useState(false);

  // ✅ LOGIN FUNCTION
  const handleLogin = async () => {
    setErrors({ email: "", password: "", general: "" });

    // ✅ FRONTEND VALIDATION
    let hasError = false;

    if (!email) {
      setErrors((prev) => ({ ...prev, email: "Email is required" }));
      hasError = true;
    }

    if (!password) {
      setErrors((prev) => ({ ...prev, password: "Password is required" }));
      hasError = true;
    }

    if (hasError) return;

    setLoading(true);

    try {
      const res = await fetch("http://localhost:8000/api/v1/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();

      if (!res.ok) {
        // ✅ BACKEND FIELD ERRORS
        if (data.detail?.field) {
          setErrors((prev) => ({
            ...prev,
            [data.detail.field]: data.detail.message
          }));
        } else {
          setErrors((prev) => ({
            ...prev,
            general: data.detail || "Login failed"
          }));
        }
        setLoading(false);
        return;
      }

      // ✅ SUCCESS → GO TO OTP
      navigate("/otp", { state: { email } });

    } catch (err) {
      setErrors({
        email: "",
        password: "",
        general: "Server error. Please try again."
      });
    }

    setLoading(false);
  };

  return (
    <div className="container">

      {/* LEFT SIDE */}
      <div
        className="left"
        style={{
          backgroundImage: `url(${loginImg})`
        }}
      ></div>

      {/* RIGHT SIDE */}
      <div className="right">
        <div className="form">

          {/* HEADER */}
          <div className="form-header">
            <h2 className="logo">LaEsfera</h2>
            <h3 className="heading">Sign In</h3>
            <p className="subtitle">
              Welcome! Please Enter your Login Details
            </p>
          </div>

          {/* EMAIL */}
          <div className="field">
            <div className={`input ${errors.email ? "input-error" : ""}`}>
              <svg className="icon" viewBox="0 0 24 24">
                <path d="M4 6h16v12H4z" fill="none" stroke="currentColor" strokeWidth="2" />
                <path d="M4 6l8 6 8-6" fill="none" stroke="currentColor" strokeWidth="2" />
              </svg>
              <input
                type="email"
                placeholder="Enter Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            {errors.email && (
              <p className="error-text">{errors.email}</p>
            )}
          </div>

          {/* PASSWORD */}
          <div className="field">
            <div className={`input ${errors.password ? "input-error" : ""}`}>
              <svg className="icon" viewBox="0 0 24 24">
                <rect x="5" y="11" width="14" height="10" rx="2" fill="none" stroke="currentColor" strokeWidth="2" />
                <path d="M8 11V7a4 4 0 018 0v4" fill="none" stroke="currentColor" strokeWidth="2" />
              </svg>
              <input
                type="password"
                placeholder="Enter Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {errors.password && (
              <p className="error-text">{errors.password}</p>
            )}
          </div>

          {/* OPTIONS */}
          <div className="options">
            <label>
              <input type="checkbox" /> Remember Me
            </label>
            <a href="#">Forgot Password?</a>
          </div>

          {/* GENERAL ERROR */}
          {errors.general && (
            <p className="error-text">{errors.general}</p>
          )}

          {/* BUTTON */}
          <button
            className="login-btn"
            onClick={handleLogin}
            disabled={loading}
          >
            {loading ? "Logging in..." : "Log Me In"}
          </button>

          <div className="divider"></div>

          <p className="terms">
            I agree to the <span>Terms & Conditions</span> and{" "}
            <span>Privacy Policy</span>
          </p>

        </div>
      </div>

    </div>
  );
};

export default LoginPage;